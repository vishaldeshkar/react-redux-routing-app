# angular-dropdown-with-large-data-set

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-dropdown-with-large-data-set)