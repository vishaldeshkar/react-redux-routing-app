import { Component } from '@angular/core';
import {
  Observable,
  Subject,
  BehaviorSubject,
  of,
  concat,
  merge,
  combineLatest,
} from 'rxjs';
import {
  switchMap,
  scan,
  tap,
  distinctUntilChanged,
  startWith,
  withLatestFrom,
  concatMap,
  map,
} from 'rxjs/operators';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  options$: Observable<any>;

  offset$: Subject<any> = new BehaviorSubject(0);
  search$: Subject<any> = new BehaviorSubject(null);


  ngOnInit() {
    this.options$ = this.offset$.pipe(
      withLatestFrom(this.search$),
      switchMap(([offset, search]) => this.getOptions(offset, search)),
      withLatestFrom(this.offset$),
      scan((acc, [currOptions, currOffset]) => currOffset === 0 ? currOptions : [...acc, ...currOptions], []),
    )
  }

  getOptions(offset, term): Observable<any> {
    const data = [];

    for (let index = offset; index < offset + 10; index++) {
      const label = term ? term : 'option';
      data.push(label + index);
    }

    return of(data);
  }

  nextPage(offset) {
    this.offset$.next(offset);
  }

  search(term) {
    this.search$.next(term);
    this.offset$.next(0);
  }
}
