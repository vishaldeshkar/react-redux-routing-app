import { Component, ChangeDetectorRef } from "@angular/core";
import { ListRange } from "@angular/cdk/collections";
import { FormControl } from "@angular/forms";

/** @title Select with reset option */
@Component({
  selector: "select-reset-example",
  templateUrl: "select-reset-example.html",
  styleUrls: ["select-reset-example.css"]
})
export class SelectResetExample {
  states: string[] = [];
  form = new FormControl();

  constructor(private cdr: ChangeDetectorRef) {
    for (let i = 1; i < 1000; i++) {
      this.states.push(`Option ${i}`);
    }
  }
}

/**  Copyright 2018 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */
