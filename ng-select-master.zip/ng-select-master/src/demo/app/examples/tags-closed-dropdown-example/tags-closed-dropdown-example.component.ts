import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'tags-closed-dropdown-example',
    templateUrl: './tags-closed-dropdown-example.component.html',
    styleUrls: ['./tags-closed-dropdown-example.component.scss']
})
export class TagsClosedDropdownExampleComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
