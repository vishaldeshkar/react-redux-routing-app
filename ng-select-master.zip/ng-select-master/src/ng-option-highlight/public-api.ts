/*
 * Public API Surface of ng-option-highlight
 */

export * from './lib/ng-option-highlight.directive';
export * from './lib/ng-option-highlight.module';
